namespace Inventory.Animal {
    public class AnimalStateAttracted : AnimalState {
        public override void OnEnter(AnimalStateManager manager) {
            
        }

        public override void OnUpdate(AnimalStateManager manager) {
            
        }

        public override void OnFixedUpdate(AnimalStateManager manager) {
            
        }

        public override void OnCollisionEnter(AnimalStateManager manager) {
            
        }
    }
}